<?php
// Database connection parameters
$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "gamerlottery";

// Create connection
$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);